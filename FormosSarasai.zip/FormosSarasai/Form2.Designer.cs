﻿namespace FormosSarasai
{
    partial class addFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pav = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.gram = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.balt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rieb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.angl = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.visa = new System.Windows.Forms.TextBox();
            this.errorPav = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorGram = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorBalt = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorRieb = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorAngl = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorPav)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorGram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBalt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorRieb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorAngl)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 16.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(68, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Įveskite savo produktą:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pavadinimas";
            // 
            // pav
            // 
            this.pav.Location = new System.Drawing.Point(200, 113);
            this.pav.Name = "pav";
            this.pav.Size = new System.Drawing.Size(252, 22);
            this.pav.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Gramai";
            // 
            // gram
            // 
            this.gram.Location = new System.Drawing.Point(200, 164);
            this.gram.Name = "gram";
            this.gram.Size = new System.Drawing.Size(252, 22);
            this.gram.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Baltymų (g)";
            // 
            // balt
            // 
            this.balt.Location = new System.Drawing.Point(200, 218);
            this.balt.Name = "balt";
            this.balt.Size = new System.Drawing.Size(252, 22);
            this.balt.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(75, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Riebalų (g)";
            // 
            // rieb
            // 
            this.rieb.Location = new System.Drawing.Point(200, 281);
            this.rieb.Name = "rieb";
            this.rieb.Size = new System.Drawing.Size(252, 22);
            this.rieb.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(75, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Angliavandenių (g)";
            // 
            // angl
            // 
            this.angl.Location = new System.Drawing.Point(200, 336);
            this.angl.Name = "angl";
            this.angl.Size = new System.Drawing.Size(252, 22);
            this.angl.TabIndex = 10;
            this.angl.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button1.Location = new System.Drawing.Point(72, 427);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 35);
            this.button1.TabIndex = 11;
            this.button1.Text = "Įvesti";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // visa
            // 
            this.visa.Location = new System.Drawing.Point(72, 477);
            this.visa.Name = "visa";
            this.visa.Size = new System.Drawing.Size(701, 22);
            this.visa.TabIndex = 12;
            // 
            // errorPav
            // 
            this.errorPav.ContainerControl = this;
            // 
            // errorGram
            // 
            this.errorGram.ContainerControl = this;
            // 
            // errorBalt
            // 
            this.errorBalt.ContainerControl = this;
            // 
            // errorRieb
            // 
            this.errorRieb.ContainerControl = this;
            // 
            // errorAngl
            // 
            this.errorAngl.ContainerControl = this;
            // 
            // addFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 556);
            this.Controls.Add(this.visa);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.angl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rieb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.balt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gram);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pav);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "addFood";
            this.Text = "Produkto įvedimas";
            ((System.ComponentModel.ISupportInitialize)(this.errorPav)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorGram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBalt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorRieb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorAngl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox pav;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox gram;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox balt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox rieb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox angl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox visa;
        private System.Windows.Forms.ErrorProvider errorPav;
        private System.Windows.Forms.ErrorProvider errorGram;
        private System.Windows.Forms.ErrorProvider errorBalt;
        private System.Windows.Forms.ErrorProvider errorRieb;
        private System.Windows.Forms.ErrorProvider errorAngl;
    }
}