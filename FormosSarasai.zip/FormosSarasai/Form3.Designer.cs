﻿namespace FormosSarasai
{
    partial class Pagrindinis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pagrindinisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dienosValgiųPasirinkimasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.išėjimasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redagavimasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savųValgiųĮtraukimasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.daržovėsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagrindiniaiValgiaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.košėsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vaisiaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aliejaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.išėjimasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pagrindinisToolStripMenuItem,
            this.redagavimasToolStripMenuItem,
            this.išėjimasToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pagrindinisToolStripMenuItem
            // 
            this.pagrindinisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dienosValgiųPasirinkimasToolStripMenuItem,
            this.išėjimasToolStripMenuItem});
            this.pagrindinisToolStripMenuItem.Name = "pagrindinisToolStripMenuItem";
            this.pagrindinisToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
            this.pagrindinisToolStripMenuItem.Text = "Pagrindinis";
            // 
            // dienosValgiųPasirinkimasToolStripMenuItem
            // 
            this.dienosValgiųPasirinkimasToolStripMenuItem.Name = "dienosValgiųPasirinkimasToolStripMenuItem";
            this.dienosValgiųPasirinkimasToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.dienosValgiųPasirinkimasToolStripMenuItem.Text = "Dienos valgių pasirinkimas...";
            this.dienosValgiųPasirinkimasToolStripMenuItem.Click += new System.EventHandler(this.dienosValgiųPasirinkimasToolStripMenuItem_Click);
            // 
            // išėjimasToolStripMenuItem
            // 
            this.išėjimasToolStripMenuItem.Name = "išėjimasToolStripMenuItem";
            this.išėjimasToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.išėjimasToolStripMenuItem.Text = "Išėjimas";
            this.išėjimasToolStripMenuItem.Click += new System.EventHandler(this.išėjimasToolStripMenuItem_Click);
            // 
            // redagavimasToolStripMenuItem
            // 
            this.redagavimasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.savųValgiųĮtraukimasToolStripMenuItem});
            this.redagavimasToolStripMenuItem.Name = "redagavimasToolStripMenuItem";
            this.redagavimasToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.redagavimasToolStripMenuItem.Text = "Redagavimas";
            // 
            // savųValgiųĮtraukimasToolStripMenuItem
            // 
            this.savųValgiųĮtraukimasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.daržovėsToolStripMenuItem,
            this.pagrindiniaiValgiaiToolStripMenuItem,
            this.košėsToolStripMenuItem,
            this.vaisiaiToolStripMenuItem,
            this.aliejaiToolStripMenuItem});
            this.savųValgiųĮtraukimasToolStripMenuItem.Name = "savųValgiųĮtraukimasToolStripMenuItem";
            this.savųValgiųĮtraukimasToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.savųValgiųĮtraukimasToolStripMenuItem.Text = "Savų valgių įtraukimas";
            // 
            // daržovėsToolStripMenuItem
            // 
            this.daržovėsToolStripMenuItem.Name = "daržovėsToolStripMenuItem";
            this.daržovėsToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.daržovėsToolStripMenuItem.Text = "Daržovės...";
            this.daržovėsToolStripMenuItem.Click += new System.EventHandler(this.daržovėsToolStripMenuItem_Click);
            // 
            // pagrindiniaiValgiaiToolStripMenuItem
            // 
            this.pagrindiniaiValgiaiToolStripMenuItem.Name = "pagrindiniaiValgiaiToolStripMenuItem";
            this.pagrindiniaiValgiaiToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.pagrindiniaiValgiaiToolStripMenuItem.Text = "Pagrindiniai valgiai...";
            this.pagrindiniaiValgiaiToolStripMenuItem.Click += new System.EventHandler(this.pagrindiniaiValgiaiToolStripMenuItem_Click);
            // 
            // košėsToolStripMenuItem
            // 
            this.košėsToolStripMenuItem.Name = "košėsToolStripMenuItem";
            this.košėsToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.košėsToolStripMenuItem.Text = "Baltyminiai valgiai...";
            this.košėsToolStripMenuItem.Click += new System.EventHandler(this.košėsToolStripMenuItem_Click);
            // 
            // vaisiaiToolStripMenuItem
            // 
            this.vaisiaiToolStripMenuItem.Name = "vaisiaiToolStripMenuItem";
            this.vaisiaiToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.vaisiaiToolStripMenuItem.Text = "Vaisiai...";
            this.vaisiaiToolStripMenuItem.Click += new System.EventHandler(this.vaisiaiToolStripMenuItem_Click);
            // 
            // aliejaiToolStripMenuItem
            // 
            this.aliejaiToolStripMenuItem.Name = "aliejaiToolStripMenuItem";
            this.aliejaiToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.aliejaiToolStripMenuItem.Text = "Aliejai...";
            this.aliejaiToolStripMenuItem.Click += new System.EventHandler(this.aliejaiToolStripMenuItem_Click);
            // 
            // išėjimasToolStripMenuItem1
            // 
            this.išėjimasToolStripMenuItem1.Name = "išėjimasToolStripMenuItem1";
            this.išėjimasToolStripMenuItem1.Size = new System.Drawing.Size(76, 24);
            this.išėjimasToolStripMenuItem1.Text = "Išėjimas";
            this.išėjimasToolStripMenuItem1.Click += new System.EventHandler(this.išėjimasToolStripMenuItem1_Click);
            // 
            // Pagrindinis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Pagrindinis";
            this.Text = "Subalansuotas dienos valgis";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pagrindinisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dienosValgiųPasirinkimasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem išėjimasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redagavimasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savųValgiųĮtraukimasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem daržovėsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagrindiniaiValgiaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem košėsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vaisiaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aliejaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem išėjimasToolStripMenuItem1;
    }
}