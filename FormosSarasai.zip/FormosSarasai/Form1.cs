﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using System.Collections;
using System.Windows.Forms;


namespace FormosSarasai
{
    public partial class Salotos : Form
    {
        List<String> sarasas_veg = new List<String>();
        List<String> sarasas_balt = new List<String>();
        List<String> sarasas_food = new List<String>();
        List<String> sarasas_vais = new List<String>();
        List<String> sarasas_alie = new List<String>();
        List <String> sarasas_mainmeniu = new List<String>();

        BindingSource saltinis1 = new BindingSource();
        BindingSource saltinis2 = new BindingSource();
        BindingSource saltinis3 = new BindingSource();
        BindingSource saltinis4 = new BindingSource();
        BindingSource saltinis5 = new BindingSource();
        BindingSource saltinismain = new BindingSource();

        public Salotos()
        {
            InitializeComponent();
            saltinis1.DataSource = sarasas_veg;
            saltinis2.DataSource = sarasas_balt;
            saltinis3.DataSource = sarasas_food;
            saltinis4.DataSource = sarasas_vais;
            saltinis5.DataSource = sarasas_alie;
            saltinismain.DataSource = sarasas_mainmeniu;  
        }

        private void add_veg_Click(object sender, EventArgs e)
        {
            saltinis2.Clear();

            string text = File.ReadAllText("json2.json");

            var list = JsonSerializer.Deserialize<IList<Darzove>>(text);
 
            foreach (var dept in list)
            {
                string tekstas = dept.name;
                sarasas_balt.Add(tekstas);
            }

            list_balt.DataSource = saltinis2;
            saltinis2.ResetBindings(false);
        }

        private void add5_Click(object sender, EventArgs e)
        {
            saltinis1.Clear();

            string text = File.ReadAllText("json1.json");

            var list = JsonSerializer.Deserialize<IList<Darzove>>(text);

            foreach (var dept in list)
            {
                string tekstas = dept.name;
                sarasas_veg.Add(tekstas);
            }

            list_veg.DataSource = saltinis1;
            saltinis1.ResetBindings(false);
        }


        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void list_balt_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void add_food_Click(object sender, EventArgs e)
        {
            saltinis3.Clear();

            string text = File.ReadAllText("json3.json");

            var list = JsonSerializer.Deserialize<IList<Darzove>>(text);

            foreach (var dept in list)
            {
                string tekstas = dept.name;
                sarasas_food.Add(tekstas);
            }

            list_food.DataSource = saltinis3;
            saltinis3.ResetBindings(false);
        }

        private void add_vais_Click(object sender, EventArgs e)
        {
            saltinis4.Clear();

            string text = File.ReadAllText("json4.json");

            var list = JsonSerializer.Deserialize<IList<Darzove>>(text);

            foreach (var dept in list)
            {
                string tekstas = dept.name;
                sarasas_vais.Add(tekstas);
            }

            list_vais.DataSource = saltinis4;
            saltinis4.ResetBindings(false);
        }

        private void add_alie_Click(object sender, EventArgs e)
        {
            saltinis5.Clear();

            string text = File.ReadAllText("json5.json");

            var list = JsonSerializer.Deserialize<IList<Darzove>>(text);

            foreach (var dept in list)
            {
                string tekstas = dept.name;
                sarasas_alie.Add(tekstas);
            }

            list_alie.DataSource = saltinis5;
            saltinis5.ResetBindings(false);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saltinismain.Clear();
            sarasas_mainmeniu.Add(list_veg.Text);
            sarasas_mainmeniu.Add(list_balt.Text);
            sarasas_mainmeniu.Add(list_food.Text);
            sarasas_mainmeniu.Add(list_vais.Text);
            sarasas_mainmeniu.Add(list_alie.Text);
            mainMeniu.DataSource = saltinismain;
            saltinismain.ResetBindings(false);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
