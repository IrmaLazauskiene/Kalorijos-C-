﻿namespace FormosSarasai
{
    partial class Salotos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.list_veg = new System.Windows.Forms.ListBox();
            this.add_balt = new System.Windows.Forms.Button();
            this.add_veg = new System.Windows.Forms.Button();
            this.add_food = new System.Windows.Forms.Button();
            this.list_balt = new System.Windows.Forms.ListBox();
            this.list_food = new System.Windows.Forms.ListBox();
            this.list_vais = new System.Windows.Forms.ListBox();
            this.add_vais = new System.Windows.Forms.Button();
            this.list_alie = new System.Windows.Forms.ListBox();
            this.add_alie = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.mainMeniu = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.darzoveBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salotosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.darzoveBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salotosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // list_veg
            // 
            this.list_veg.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.list_veg.FormattingEnabled = true;
            this.list_veg.ItemHeight = 16;
            this.list_veg.Location = new System.Drawing.Point(27, 50);
            this.list_veg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.list_veg.Name = "list_veg";
            this.list_veg.Size = new System.Drawing.Size(399, 68);
            this.list_veg.TabIndex = 0;
            // 
            // add_balt
            // 
            this.add_balt.Location = new System.Drawing.Point(27, 422);
            this.add_balt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_balt.Name = "add_balt";
            this.add_balt.Size = new System.Drawing.Size(150, 45);
            this.add_balt.TabIndex = 2;
            this.add_balt.Text = "Pridėti/atnaujinti baltiminius produktus";
            this.add_balt.UseVisualStyleBackColor = true;
            this.add_balt.Click += new System.EventHandler(this.add_veg_Click);
            // 
            // add_veg
            // 
            this.add_veg.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add_veg.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.add_veg.FlatAppearance.BorderSize = 3;
            this.add_veg.Location = new System.Drawing.Point(27, 1);
            this.add_veg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_veg.Name = "add_veg";
            this.add_veg.Size = new System.Drawing.Size(150, 45);
            this.add_veg.TabIndex = 3;
            this.add_veg.Text = "Pridėti/atnaujinti daržoves";
            this.add_veg.UseVisualStyleBackColor = false;
            this.add_veg.Click += new System.EventHandler(this.add5_Click);
            // 
            // add_food
            // 
            this.add_food.Location = new System.Drawing.Point(27, 140);
            this.add_food.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_food.Name = "add_food";
            this.add_food.Size = new System.Drawing.Size(150, 45);
            this.add_food.TabIndex = 4;
            this.add_food.Text = "Pridėti/atnaujinti košes/žuvis";
            this.add_food.UseVisualStyleBackColor = true;
            this.add_food.Click += new System.EventHandler(this.add_food_Click);
            // 
            // list_balt
            // 
            this.list_balt.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.list_balt.FormattingEnabled = true;
            this.list_balt.ItemHeight = 16;
            this.list_balt.Location = new System.Drawing.Point(27, 470);
            this.list_balt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.list_balt.Name = "list_balt";
            this.list_balt.Size = new System.Drawing.Size(399, 68);
            this.list_balt.TabIndex = 8;
            this.list_balt.SelectedIndexChanged += new System.EventHandler(this.list_balt_SelectedIndexChanged);
            // 
            // list_food
            // 
            this.list_food.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.list_food.FormattingEnabled = true;
            this.list_food.ItemHeight = 16;
            this.list_food.Location = new System.Drawing.Point(27, 189);
            this.list_food.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.list_food.Name = "list_food";
            this.list_food.Size = new System.Drawing.Size(399, 68);
            this.list_food.TabIndex = 9;
            // 
            // list_vais
            // 
            this.list_vais.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.list_vais.FormattingEnabled = true;
            this.list_vais.ItemHeight = 16;
            this.list_vais.Location = new System.Drawing.Point(27, 614);
            this.list_vais.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.list_vais.Name = "list_vais";
            this.list_vais.Size = new System.Drawing.Size(399, 68);
            this.list_vais.TabIndex = 11;
            // 
            // add_vais
            // 
            this.add_vais.Location = new System.Drawing.Point(27, 565);
            this.add_vais.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_vais.Name = "add_vais";
            this.add_vais.Size = new System.Drawing.Size(150, 45);
            this.add_vais.TabIndex = 10;
            this.add_vais.Text = "Pridėti/atnaujinti vaisius";
            this.add_vais.UseVisualStyleBackColor = true;
            this.add_vais.Click += new System.EventHandler(this.add_vais_Click);
            // 
            // list_alie
            // 
            this.list_alie.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.list_alie.FormattingEnabled = true;
            this.list_alie.ItemHeight = 16;
            this.list_alie.Location = new System.Drawing.Point(27, 331);
            this.list_alie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.list_alie.Name = "list_alie";
            this.list_alie.Size = new System.Drawing.Size(399, 68);
            this.list_alie.TabIndex = 13;
            // 
            // add_alie
            // 
            this.add_alie.Location = new System.Drawing.Point(27, 282);
            this.add_alie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_alie.Name = "add_alie";
            this.add_alie.Size = new System.Drawing.Size(150, 45);
            this.add_alie.TabIndex = 12;
            this.add_alie.Text = "Pridėti/atnaujinti aliejus";
            this.add_alie.UseVisualStyleBackColor = true;
            this.add_alie.Click += new System.EventHandler(this.add_alie_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(592, 148);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 25);
            this.label1.TabIndex = 14;
            this.label1.Text = "Jūsų pasirinktas meniu:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button1.Location = new System.Drawing.Point(870, 140);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 42);
            this.button1.TabIndex = 15;
            this.button1.Text = "Įkelti";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // mainMeniu
            // 
            this.mainMeniu.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.mainMeniu.FormattingEnabled = true;
            this.mainMeniu.ItemHeight = 16;
            this.mainMeniu.Location = new System.Drawing.Point(597, 189);
            this.mainMeniu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mainMeniu.Name = "mainMeniu";
            this.mainMeniu.Size = new System.Drawing.Size(399, 180);
            this.mainMeniu.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(592, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(408, 25);
            this.label2.TabIndex = 17;
            this.label2.Text = "Pasirinkite po vieną valgį iš 5-ių maisto grupių.";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // salotosBindingSource
            // 
            this.salotosBindingSource.DataSource = typeof(FormosSarasai.Salotos);
            // 
            // Salotos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FormosSarasai.Properties.Resources.braškės;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1137, 695);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mainMeniu);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.list_alie);
            this.Controls.Add(this.add_alie);
            this.Controls.Add(this.list_vais);
            this.Controls.Add(this.add_vais);
            this.Controls.Add(this.list_food);
            this.Controls.Add(this.list_balt);
            this.Controls.Add(this.add_food);
            this.Controls.Add(this.add_veg);
            this.Controls.Add(this.add_balt);
            this.Controls.Add(this.list_veg);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Salotos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Maistas";
            ((System.ComponentModel.ISupportInitialize)(this.darzoveBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salotosBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox list_veg;
        private System.Windows.Forms.Button add_balt;
        private System.Windows.Forms.Button add_veg;
        private System.Windows.Forms.Button add_food;
        private System.Windows.Forms.BindingSource salotosBindingSource;
        private System.Windows.Forms.BindingSource darzoveBindingSource;
        private System.Windows.Forms.ListBox list_balt;
        private System.Windows.Forms.ListBox list_food;
        private System.Windows.Forms.ListBox list_vais;
        private System.Windows.Forms.Button add_vais;
        private System.Windows.Forms.ListBox list_alie;
        private System.Windows.Forms.Button add_alie;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox mainMeniu;
        private System.Windows.Forms.Label label2;
    }
}

