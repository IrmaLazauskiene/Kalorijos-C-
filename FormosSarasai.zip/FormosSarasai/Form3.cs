﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormosSarasai
{
    public partial class Pagrindinis : Form
    {
        public Pagrindinis()
        {
            InitializeComponent();
        }

        private void dienosValgiųPasirinkimasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Salotos r = new Salotos();
            r.MdiParent = this;
            r.Show();
        }

        private void daržovėsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addFood r = new addFood("json1.json");
            r.MdiParent = this;
            r.Show();
        }

        private void išėjimasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void košėsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addFood r = new addFood("json2.json");
            r.MdiParent = this;
            r.Show();
        }

        private void išėjimasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pagrindiniaiValgiaiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addFood r = new addFood("json3.json");
            r.MdiParent = this;
            r.Show();
        }

        private void vaisiaiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addFood r = new addFood("json4.json");
            r.MdiParent = this;
            r.Show();
        }

        private void aliejaiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addFood r = new addFood("json5.json");
            r.MdiParent = this;
            r.Show();
        }
    }
}
