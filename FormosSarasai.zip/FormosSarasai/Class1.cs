﻿using System;

namespace FormosSarasai
{
    public class Darzove
    {
        public string name { get; set; }
        public int grm { get; set; }
        public double ang { get; set; }
        public double blt { get; set; }
        public double rbl { get; set; }
    }
}
