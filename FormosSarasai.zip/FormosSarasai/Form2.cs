﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.Collections;
using Newtonsoft.Json;
using System.IO;

namespace FormosSarasai
{
    public partial class addFood : Form
    {
        private string file_name;

        public addFood(string file_name)
        {
            this.file_name = file_name;
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tikrinkDuomenys())
            {
                string text1 = File.ReadAllText(file_name);
                var list = System.Text.Json.JsonSerializer.Deserialize<IList<Darzove>>(text1);

                Darzove d = new Darzove()
                {
                    name = pav.Text,
                    grm = Convert.ToInt16(gram.Text),
                    ang = Convert.ToDouble(angl.Text),
                    blt = Convert.ToDouble(balt.Text),
                    rbl = Convert.ToDouble(rieb.Text)
                };

                list.Add(d);

                string text = JsonConvert.SerializeObject(list);

                visa.Text = d.name;

                File.WriteAllText(file_name, text);
            }


        }

        private bool tikrinkDuomenys()
        {
            bool ok = true;

            if (pav.Text == "")
            {
                ok = false;
                errorPav.SetError(pav, "Įveskite produkto pavadinimą.");
            }

            if (gram.Text == "")
            {
                ok = false;
                errorGram.SetError(gram, "Įveskite produkto svorį gramais.");
            }

            if (angl.Text == "")
            {
                ok = false;
                errorAngl.SetError(angl, "Įveskite produkto angliavandenių kiekį gramais.");
            }

            if (balt.Text == "")
            {
                ok = false;
                errorBalt.SetError(balt, "Įveskite produkto baltymų kiekį gramais.");
            }

            if (rieb.Text == "")
            {
                ok = false;
                errorRieb.SetError(rieb, "Įveskite produkto riebalų kiekį gramais.");
            }

            return ok;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
