﻿using System;
using System.IO;
using System.Text.Json;
using System.Collections.Generic;

namespace Kalorijos
{
    class program
    {
        static string Duomenys(string failas)
        {
            string text = File.ReadAllText(failas);
            return text;
        }

        static void Rezultatas (string eilute)
        {
            int nr = 0;

            var angltList = JsonSerializer.Deserialize<IList<Darzove>>(eilute);

            foreach (var dept in angltList)
            {

                nr++;

                String tekstas = dept.name + " / " + dept.grm;

         //       Console.WriteLine("{0}:{1}", nr, tekstas);
            }
        }

        static void Main(string[] args)
        {
            string salotosText = Duomenys("json1.json");
            string garnyrasText = Duomenys("json2.json");
            string maistasText = Duomenys("json3.json");
            string vaisiasiText = Duomenys("json4.json");
            string aliejaiText = Duomenys("json5.json");

            Console.WriteLine("Maistas: "); Console.WriteLine();

        /*    Rezultatas(salotosText); Console.WriteLine();
            Rezultatas(garnyrasText); Console.WriteLine();
            Rezultatas(maistasText); Console.WriteLine();
            Rezultatas(vaisiasiText); Console.WriteLine();
            Rezultatas(aliejaiText); Console.WriteLine();*/
        }
    }
}
