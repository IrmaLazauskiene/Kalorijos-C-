﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalorijos
{
    public partial class reikia : Form
    {
        public reikia()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        static double Skaiciuoti(double kfsvoris, double svoris, double kfugis, double ugis, double kfamzius, double amzius)
        {
            double kcal = 650 + kfsvoris * svoris + kfugis * ugis - kfamzius * amzius;
            return kcal;
        }

        static double Koeficientas (string aktyvumas)
        {
            double kof = 1;
            if (aktyvumas == "Lengvai sportuoju.")
            {
                kof = 1.4;
            }
            if (aktyvumas == "Aktyviai sportuoju.")
            {
                kof = 1.7;
            }
            return kof;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string lytis=comboBox1.Text;

            double amzius = Convert.ToDouble(textBox1.Text);
            double svoris = Convert.ToDouble(textBox2.Text);
            double ugis = Convert.ToDouble(textBox3.Text);

            string aktyvumas = comboBox2.Text;
            double kof = Koeficientas(aktyvumas);

            if (lytis == "M")
            {
               textBox4.Text = Convert.ToString(Skaiciuoti(9.6,svoris,1.8,ugis,4.7,amzius) * kof);     
            }
            if (lytis == "V")
            {
                textBox4.Text = Convert.ToString(Skaiciuoti(13.7,svoris,5,ugis,6.8,amzius) * kof);
            }
            
        }

        private void reikia_Load(object sender, EventArgs e)
        {

        }
    }
}
